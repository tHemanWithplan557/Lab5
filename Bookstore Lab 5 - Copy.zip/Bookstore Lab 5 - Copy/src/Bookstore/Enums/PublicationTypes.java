// Student Name: Xavier Henderson
// LSU ID: 896202961
// Assignment: Lab 5

package Bookstore.Enums;

public enum PublicationTypes {
	PUBLICATION,
	BOOK,
	MAGAZINE,
	RESEARCH,
	

}
