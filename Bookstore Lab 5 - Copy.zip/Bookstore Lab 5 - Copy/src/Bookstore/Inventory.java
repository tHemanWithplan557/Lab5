// Student Name: Xavier Henderson
// LSU ID: 896202961
// Assignment: Lab 5

package Bookstore;

import java.util.ArrayList;
import java.util.Collections;

import Bookstore.Publications.Publication;

public class Inventory {
	private ArrayList<Publication> publications;

	public Inventory(){
		publications = new ArrayList<>();
	}

	public void addPublication(Publication p){
		publications.add(p);
	}

	public void listInventory(){
		Collections.sort(publications);
		for(Publication pub: publications){
			pub.printInfo();
		}
	}
}
