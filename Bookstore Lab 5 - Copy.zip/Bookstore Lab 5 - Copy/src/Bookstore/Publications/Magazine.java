// Student Name: Xavier Henderson
// LSU ID: 896202961
// Assignment: Lab 5

package Bookstore.Publications;

public class Magazine extends Publication{
	private int issue;
	private int volume;
	private String publisher;

	// TODO - Create the constructor for Magazine
	// It will take in a String title, String genre,
	// int issue, int volume, and String publisher
	public Magazine(String title, String genre, int issue, int volume, String publisher) {
        super(title, genre);
        this.issue = issue;
        this.volume = volume;
        this.publisher = publisher;
    }
	@Override
	public void printInfo() {
		// TODO - Override Publication's printInfo to display the following format:
	// "[title] was published by [publisher] in Volume [volume] issue [issue] :: [genre]"
		System.out.printf("%s was published by %s in Volume %d issue %d :: %s%n",
			    title, publisher, issue, volume, genre);
	}
}
