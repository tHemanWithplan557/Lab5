// Student Name: Xavier Henderson
// LSU ID: 896202961
// Assignment: Lab 5

package Bookstore.Publications;

public class Publication implements Comparable<Publication>{
	// Instance variables
	protected String title;
	protected String genre;

	public Publication(String t, String g){
		title = t;
		genre = g;
	}

	public void printInfo(){
		System.out.printf("%s :: %s%n", title, genre);
	}

	@Override
	public int compareTo(Publication p) {
		//TODO - Implement the compareTo method so that
		// Publications are sorted based on Genre then by Title
		int genreCompare = this.genre.compareTo(p.genre);
		
		if (genreCompare != 0) {
			return genreCompare;
		}
		
		return this.title.compareTo(p.title);
		}
		
	}


