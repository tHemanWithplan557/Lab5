// Student Name: Xavier Henderson
// LSU ID: 896202961
// Assignment: Lab 5

package Bookstore.Publications;

public class Book extends Publication{
	private String author;
	private String publisher;
	private int publicationYear;

	
	
	public Book(String title, String genre, String author, String publisher, int publicationYear) {
		super(title, genre); // REQUIRED
		this.author = author;
		this.publisher = publisher;
		this.publicationYear = publicationYear;
	}

	@Override
	public void printInfo() {
		
		System.out.printf("%s by %s was published by %s in %d :: %s%n",
                title, author, publisher, publicationYear, genre); 
	}
}
