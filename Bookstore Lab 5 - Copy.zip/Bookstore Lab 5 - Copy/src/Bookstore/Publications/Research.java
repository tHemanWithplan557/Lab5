// Student Name: Xavier Henderson
// LSU ID: 896202961
// Assignment: Lab 5

package Bookstore.Publications;

public class Research extends Publication{
	private String[] authors;
	private String journal;
	private int publicationYear;

	// TODO - Create the constructor for Research
	// It will take in a String title, String genre,
	// String[] authors, String journal, and int publication year
	public Research(String title, String genre, String[] authors, String journal, int publicationYear) {
	super(title, genre);
	this.authors = authors;
	this.journal = journal;
	this.publicationYear = publicationYear;
	}

	@Override
	public void printInfo() {
		// TODO - Override Publication's printInfo to display the following format:
		// "[title] by [authors] was published in [journal] in [publication year] :: [genre]"
		// NOTE - if the number of authors is greater than 1, the print out for [authors]
		// should be the following format "[first author's name] et al."
		
		String authorDisplay;
        if (authors.length > 1) {
            authorDisplay = authors[0] + " et al.";
        } else {
            authorDisplay = authors[0];
        }
        System.out.printf("%s by %s was published in %s in %d :: %s%n",
                title, authorDisplay, journal, publicationYear, genre);
    }
}